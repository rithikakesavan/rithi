#include <stdio.h>
#include "student.h"

int main() {
    int ch;
    do {
        printf("\n1.Add Student\n2.View Students\n3.Exit\nChoice: ");
        scanf("%d",&ch);

        switch(ch) {
            case 1: addStudent(); break;
            case 2: viewStudents(); break;
        }
    } while(ch!=3);

    return 0;
}
