# Student Database Management System (C)

## Features
- Add student records
- View student records
- File I/O using binary file (students.dat)
- Modular design using .c and .h files
- Makefile for compilation

## Project Structure
- main.c
- student.c
- student.h
- Makefile
- README.md

## Compile
make

## Run
./studentdb

## Data Structure
typedef struct {
    int id;
    char name[50];
    float marks;
} Student;
