#include <stdio.h>
#include "student.h"

void addStudent() {
    FILE *fp=fopen("students.dat","ab");
    Student s;
    printf("ID: "); scanf("%d",&s.id);
    printf("Name: "); scanf("%s",s.name);
    printf("Marks: "); scanf("%f",&s.marks);
    fwrite(&s,sizeof(Student),1,fp);
    fclose(fp);
}

void viewStudents() {
    FILE *fp=fopen("students.dat","rb");
    Student s;
    if(!fp){printf("No records found\n"); return;}
    while(fread(&s,sizeof(Student),1,fp))
        printf("%d %s %.2f\n",s.id,s.name,s.marks);
    fclose(fp);
}
