#ifndef STUDENT_H
#define STUDENT_H

typedef struct {
    int id;
    char name[50];
    float marks;
} Student;

void addStudent();
void viewStudents();

#endif
