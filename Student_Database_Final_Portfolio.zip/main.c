#include <stdio.h>
#include "student.h"

/* Main menu-driven program */
int main() {
    int choice;

    do {
        printf("\n1. Add Student\n");
        printf("2. View Students\n");
        printf("3. Exit\n");
        printf("Choice: ");
        scanf("%d",&choice);

        switch(choice) {
            case 1: addStudent(); break;
            case 2: viewStudents(); break;
            case 3: printf("Exiting...\n"); break;
            default: printf("Invalid choice\n");
        }
    } while(choice != 3);

    return 0;
}
