# Student Database Management System

## Overview
A simple Student Database Management System written in C using modular programming.

## Features
- Add student records
- View student records
- Persistent storage using binary files
- Modular design with .c and .h files
- Makefile-based compilation

## Memory Check
No dynamic memory allocation is used; therefore no memory leaks occur.
Recommended Valgrind command:

valgrind --leak-check=full ./studentdb

Expected result:
All heap blocks were freed -- no leaks are possible.

## File Structure
- main.c
- student.c
- student.h
- Makefile
- README.md

## Build
make

## Run
./studentdb

## Example
1. Add Student
2. View Students
3. Exit

## Optimization
- Sequential file access
- Minimal memory usage
- Efficient binary file storage
